import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { supabase, GeneratedPage } from '../lib/supabase';
import { Loader2, Check, ArrowLeft } from 'lucide-react';

type Props = {
  pageId: string;
};

export function PageView({ pageId }: Props) {
  const [page, setPage] = useState<GeneratedPage | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPage();
  }, [pageId]);

  const loadPage = async () => {
    try {
      const { data, error } = await supabase
        .from('generated_pages')
        .select('*')
        .eq('id', pageId)
        .maybeSingle();

      if (error) throw error;
      setPage(data);
    } catch (err) {
      console.error('Error loading page:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950">
        <Header />
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-gray-400 animate-spin" />
        </div>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="min-h-screen bg-gray-950">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-400">Page not found</p>
          <a href="/dashboard" className="text-blue-500 hover:text-blue-400 mt-4 inline-block">
            Back to Dashboard
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <a
          href="/dashboard"
          className="inline-flex items-center space-x-2 text-gray-400 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </a>

        <div className="bg-gradient-to-br from-blue-900/20 to-gray-900 rounded-2xl border border-gray-800 overflow-hidden">
          <div className="p-8 sm:p-12 lg:p-16">
            <div className="text-center mb-12">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                {page.headline}
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                {page.copy}
              </p>
            </div>

            <div className="flex justify-center mb-12">
              <button className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-lg transition-colors duration-200 shadow-lg shadow-blue-900/30">
                {page.cta_text}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {page.features.map((feature, index) => (
                <div
                  key={index}
                  className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 hover:border-gray-700 transition-colors"
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <p className="text-gray-200 font-medium">{feature}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/80 border-t border-gray-800 px-8 py-6">
            <div className="max-w-5xl mx-auto">
              <h3 className="text-sm font-semibold text-gray-400 mb-3">Product Description:</h3>
              <p className="text-gray-500 text-sm">{page.product_description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
