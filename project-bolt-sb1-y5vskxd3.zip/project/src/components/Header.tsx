import { useAuth } from '../contexts/AuthContext';
import { Sparkles, LogOut } from 'lucide-react';

export function Header() {
  const { signOut, user } = useAuth();

  return (
    <header className="bg-gray-900 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-8 h-8 text-blue-500" />
            <a href="/dashboard" className="text-2xl font-bold text-white">
              SellPage AI
            </a>
          </div>

          <nav className="flex items-center space-x-6">
            <a
              href="/dashboard"
              className="text-gray-300 hover:text-white transition-colors"
            >
              Dashboard
            </a>
            <a
              href="/pricing"
              className="text-gray-300 hover:text-white transition-colors"
            >
              Pricing
            </a>
            <div className="flex items-center space-x-4 pl-6 border-l border-gray-800">
              <span className="text-sm text-gray-400">{user?.email}</span>
              <button
                onClick={() => signOut()}
                className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign out</span>
              </button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
