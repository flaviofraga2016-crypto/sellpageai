/*
  # Create early access emails table

  1. New Tables
    - `early_access_emails`
      - `id` (uuid, primary key)
      - `email` (text, unique, not null)
      - `created_at` (timestamp with time zone)
      - `subscribed` (boolean, default true)
  
  2. Security
    - Enable RLS on `early_access_emails` table
    - Add policy for public insert access (anyone can join waitlist)
    - No public read access (only admin can see emails)
  
  3. Notes
    - Email addresses are stored securely
    - Duplicate emails are prevented by unique constraint
    - Created_at timestamp for tracking signup order
*/

CREATE TABLE IF NOT EXISTS early_access_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  subscribed boolean DEFAULT true
);

ALTER TABLE early_access_emails ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can join waitlist"
  ON early_access_emails
  FOR INSERT
  TO anon
  WITH CHECK (true);
