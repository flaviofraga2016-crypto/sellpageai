import { Header } from '../components/Header';
import { Check, Sparkles } from 'lucide-react';

export function Pricing() {
  return (
    <div className="min-h-screen bg-gray-950">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Start generating high-converting landing pages today
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <div className="bg-gradient-to-br from-blue-900/20 to-gray-900 border-2 border-blue-500 rounded-2xl p-8 relative overflow-hidden">
            <div className="absolute top-4 right-4">
              <span className="bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                Most Popular
              </span>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-2">Pro Plan</h2>
              <div className="flex items-baseline space-x-2 mb-4">
                <span className="text-5xl font-bold text-white">$9</span>
                <span className="text-gray-400">/month</span>
              </div>
              <p className="text-gray-400">
                Everything you need to create stunning landing pages
              </p>
            </div>

            <ul className="space-y-4 mb-8">
              {[
                'Unlimited page generations',
                'AI-powered copywriting',
                'High-converting templates',
                'Save all your pages',
                'Custom headlines & CTAs',
                'Feature highlighting',
                'Modern, responsive designs',
                'Priority support',
              ].map((feature, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center mt-0.5">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-gray-300">{feature}</span>
                </li>
              ))}
            </ul>

            <button className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 shadow-lg shadow-blue-900/30">
              <Sparkles className="w-5 h-5" />
              <span>Get Started Now</span>
            </button>

            <p className="text-center text-sm text-gray-500 mt-6">
              Cancel anytime. No questions asked.
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-xl font-semibold text-white mb-8">
            Trusted by innovative companies
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50">
            <div className="text-gray-600 font-bold text-2xl">ACME</div>
            <div className="text-gray-600 font-bold text-2xl">TechCo</div>
            <div className="text-gray-600 font-bold text-2xl">Innovate</div>
            <div className="text-gray-600 font-bold text-2xl">Future</div>
          </div>
        </div>

        <div className="mt-20 bg-gray-900 border border-gray-800 rounded-xl p-8 max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold text-white mb-4 text-center">
            Frequently Asked Questions
          </h3>
          <div className="space-y-6 mt-8">
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">
                How does the AI generation work?
              </h4>
              <p className="text-gray-400">
                Simply describe your product, and our AI will generate a complete landing page with compelling headlines, persuasive copy, and feature highlights tailored to your description.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">
                Can I edit the generated content?
              </h4>
              <p className="text-gray-400">
                Yes! All generated pages are fully editable. You can customize any element to match your brand and messaging.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">
                What if I'm not satisfied?
              </h4>
              <p className="text-gray-400">
                You can cancel your subscription at any time. No commitments, no hassle.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
