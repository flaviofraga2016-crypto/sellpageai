import { useState, useEffect } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';

type GeneratedPage = {
  headline: string;
  subheadline: string;
  solution: string;
};

export function PageGenerator() {
  const [productDescription, setProductDescription] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generatedPage, setGeneratedPage] = useState<GeneratedPage | null>(null);
  const [error, setError] = useState('');
  const [freeUsed, setFreeUsed] = useState(false);

  // verifica se já usou grátis
  useEffect(() => {
    const used = localStorage.getItem("free_page_used");
    if (used === "yes") setFreeUsed(true);
  }, []);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (freeUsed) {
      setError("Free limit reached. Upgrade to continue.");
      return;
    }

    setGenerating(true);
    setError("");

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-page-public`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ productDescription }),
        }
      );

      const data = await response.json();

      if (!response.ok) throw new Error("Error generating");

      setGeneratedPage(data.page);

      // salva que já usou grátis
      localStorage.setItem("free_page_used", "yes");
      setFreeUsed(true);

    } catch (err) {
      setError("Generation failed");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">

      {/* FORM */}
      {!generatedPage && (
        <form onSubmit={handleGenerate} className="space-y-6 bg-gray-900 p-8 rounded-2xl border border-gray-800">

          <textarea
            value={productDescription}
            onChange={(e)=>setProductDescription(e.target.value)}
            required
            rows={6}
            placeholder="Describe your product..."
            className="w-full p-4 bg-black border border-gray-700 rounded-xl text-white"
          />

          {error && (
            <div className="text-red-400 font-semibold">{error}</div>
          )}

          {freeUsed ? (
            <a
              href="https://buy.stripe.com/00w6ozfGh0gg8Pe3Hu6c000"
              className="block text-center w-full py-4 rounded-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600"
            >
              Upgrade to Pro 🚀
            </a>
          ) : (
            <button
              disabled={generating}
              className="w-full py-4 rounded-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 flex items-center justify-center gap-2"
            >
              {generating ? <Loader2 className="animate-spin"/> : <Sparkles/>}
              Generate Sales Page
            </button>
          )}
        </form>
      )}

      {/* RESULT */}
      {generatedPage && (
        <div className="bg-white text-black p-10 rounded-2xl">
          <h1 className="text-4xl font-bold mb-4">{generatedPage.headline}</h1>
          <p className="text-xl mb-6">{generatedPage.subheadline}</p>
          <p>{generatedPage.solution}</p>

          <div className="mt-10 text-center">
           <a
  href="https://buy.stripe.com/00w6ozfGh0gg8Pe3Hu6c000"
  target="_blank"
  className="inline-block px-8 py-4 rounded-xl font-bold text-white bg-gradient-to-r from-purple-600 to-pink-600"
>
  Unlock Unlimited Pages 🔥
</a>

          </div>
        </div>
      )}
    </div>
  );
}
