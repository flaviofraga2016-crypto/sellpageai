import { useState } from 'react';
import { Sparkles, Zap, TrendingUp, Users, Package, DollarSign, Rocket, Check, ArrowRight } from 'lucide-react';
import { PageGenerator } from '../components/PageGenerator';

export function Home() {
  const scrollToGenerator = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('generator-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-blue-950 to-slate-950">
      {/* Background gradient orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute top-40 right-1/3 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <header className="border-b border-white/10 bg-slate-950/80 backdrop-blur-xl fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white">SellPage AI</span>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="#generator-section"
                onClick={scrollToGenerator}
                className="text-gray-300 hover:text-white transition-colors font-medium"
              >
                Generate
              </a>
              <a
                href="#pricing"
                className="text-gray-300 hover:text-white transition-colors font-medium"
              >
                Pricing
              </a>
              <a
                href="#generator-section"
                onClick={scrollToGenerator}
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      <div className="pt-16"></div>

      <main className="relative z-10">
        {/* HERO SECTION */}
        <section className="relative py-32 px-4 overflow-hidden">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full mb-8 hover:bg-white/20 transition-all cursor-default">
              <Rocket className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-gray-200 font-medium">The AI Sales Page Generator</span>
            </div>

            <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold mb-8 leading-tight">
              <span className="text-white">Create Sales Pages</span>
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-500">
                That Actually Convert
              </span>
            </h1>

            <p className="text-xl sm:text-2xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed">
              Generate high-converting landing pages in seconds with AI. No copywriting skills needed.
            </p>

           <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">

<a
  href="#generator-section"
  onClick={(e)=>{
    e.preventDefault();
    document.getElementById("generator-section")?.scrollIntoView({behavior:"smooth"});
  }}
  className="group px-10 py-5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white text-lg font-bold rounded-xl transition-all duration-300 flex flex-col items-center shadow-2xl shadow-blue-500/40 hover:scale-105"
>
  <span className="flex items-center gap-3">
    Generate My Page Now
    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
  </span>

  <span className="text-sm opacity-80 mt-2 text-center">
    Free beta — 1 page free <br/>
    Upgrade to Pro for unlimited pages ($19/month)
  </span>
</a>


<div className="text-sm text-gray-400">
Free • No credit card required
</div>

</div>





            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-4 hover:bg-white/20 transition-all">
                <div className="text-3xl font-bold text-cyan-400">1,000+</div>
                <div className="text-sm text-gray-400 mt-2">Creators Using</div>
              </div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-4 hover:bg-white/20 transition-all">
                <div className="text-3xl font-bold text-blue-400">50k+</div>
                <div className="text-sm text-gray-400 mt-2">Pages Generated</div>
              </div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-4 hover:bg-white/20 transition-all">
                <div className="text-3xl font-bold text-cyan-400">10s</div>
                <div className="text-sm text-gray-400 mt-2">Generate Time</div>
              </div>
            </div>
          </div>
        </section>

        {/* SOCIAL PROOF SECTION */}
        <section className="py-20 px-4 bg-white/5 backdrop-blur-sm border-y border-white/10">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-white mb-16">Trusted by Serious Sellers</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { icon: Users, label: 'Used by 1,000+ Creators', desc: 'From solopreneurs to agencies' },
                { icon: TrendingUp, label: '50k+ Pages Generated', desc: 'Every day creators are selling' },
                { icon: Zap, label: 'Built for Serious Sellers', desc: 'Dropshippers, affiliates, creators' },
              ].map((item, idx) => (
                <div key={idx} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-8 hover:bg-white/20 transition-all hover:border-white/30 group">
                  <item.icon className="w-8 h-8 text-cyan-400 mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="text-lg font-semibold text-white mb-2">{item.label}</h3>
                  <p className="text-gray-400">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FEATURES SECTION */}
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-white mb-16">Why SellPage AI?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  icon: Sparkles,
                  title: 'AI Copywriting',
                  desc: 'Expert copywriting powered by GPT-4o. Generates headlines, benefits, and CTAs that sell.',
                },
                {
                  icon: TrendingUp,
                  title: 'High-Converting Structure',
                  desc: 'Pre-built sales page framework proven to convert. Problem → Solution → Benefits → CTA.',
                },
                {
                  icon: Package,
                  title: 'For All Sellers',
                  desc: 'Works for dropshippers, digital products, courses, services, and SaaS products.',
                },
                {
                  icon: Zap,
                  title: 'Instant Generation',
                  desc: 'Get a complete sales page in seconds. Edit, customize, and publish immediately.',
                },
              ].map((feature, idx) => (
                <div key={idx} className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md border border-white/20 rounded-2xl p-8 hover:border-blue-500/50 hover:bg-white/15 transition-all group">
                  <feature.icon className="w-10 h-10 text-cyan-400 mb-6 group-hover:scale-110 transition-transform" />
                  <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS SECTION */}
        <section className="py-20 px-4 bg-white/5 backdrop-blur-sm border-y border-white/10">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-white mb-16">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  step: '01',
                  title: 'Describe Your Product',
                  desc: 'Tell us about your product in 2-3 sentences. Include features, benefits, and target audience.',
                },
                {
                  step: '02',
                  title: 'AI Generates Page',
                  desc: 'Our AI creates a complete, high-converting sales page with headline, copy, benefits, and CTA.',
                },
                {
                  step: '03',
                  title: 'Copy & Sell',
                  desc: 'Copy the generated page and start selling. Customize as needed. No code required.',
                },
              ].map((item, idx) => (
                <div key={idx} className="relative">
                  <div className="bg-gradient-to-br from-blue-600/30 to-cyan-600/20 backdrop-blur-md border border-white/20 rounded-2xl p-8 h-full">
                    <div className="text-5xl font-bold text-cyan-400/30 mb-4">{item.step}</div>
                    <h3 className="text-2xl font-bold text-white mb-4">{item.title}</h3>
                    <p className="text-gray-300 leading-relaxed">{item.desc}</p>
                  </div>
                  {idx < 2 && (
                    <div className="hidden md:flex absolute top-1/2 -right-4 transform -translate-y-1/2">
                      <ArrowRight className="w-8 h-8 text-cyan-400" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* GENERATOR SECTION */}
        <section id="generator-section" className="py-20 px-4 scroll-mt-20">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-white mb-4">Try It Now - Free</h2>
              <p className="text-xl text-gray-400">Describe your product and watch AI generate your sales page</p>
            </div>

            <PageGenerator />
          </div>
        </section>

        {/* PRICING SECTION */}
        <section id="pricing" className="py-20 px-4 bg-white/5 backdrop-blur-sm border-y border-white/10">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-white mb-4">Simple Pricing</h2>
            <p className="text-center text-gray-400 mb-16 text-lg">Start free, upgrade when you're ready</p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  name: 'Free Trial',
                  price: '$0',
                  period: 'Forever free',
                  features: [
                    '1 pages/month',
                    'AI copywriting',
                    'High-converting structure',
                    'Community support',
                  ],
                  cta: 'Get Started Free',
                  link: "#generator-section"
                  highlighted: false,
                },
                {
                  name: 'Basic',
                  price: '$9',
                  period: '/month',
                  features: [
                    '100 pages/month',
                    'AI copywriting',
                    'High-converting structure',
                    'Email support',
                    'Export to multiple formats',
                  ],
                  cta: 'Start Basic',
                  link: "https://buy.stripe.com/00w6ozfGh0gg8Pe3Hu6c000",
                  highlighted: true,
                },
                {
                  name: 'Pro',
                  price: '$19',
                  period: '/month',
                  features: [
                    'Unlimited pages',
                    'AI copywriting',
                    'High-converting structure',
                    'Priority support',
                    'Export & publishing',
                    'API access',
                    'Team members',
                  ],
                  cta: 'Start Pro',
                  link: "https://buy.stripe.com/8x2bIT2Tv5AA9Ti7XK6c001",
                  highlighted: false,
                },
              ].map((plan, idx) => (
                <div
                  key={idx}
                  className={`rounded-2xl transition-all ${
                    plan.highlighted
                      ? 'bg-gradient-to-br from-blue-600/40 to-cyan-600/30 border border-blue-500/50 shadow-2xl shadow-blue-500/20 scale-105'
                      : 'bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/15 hover:border-white/30'
                  }`}
                >
                  <div className="p-8">
                    {plan.highlighted && (
                      <div className="inline-block bg-gradient-to-r from-blue-400 to-cyan-400 text-slate-950 text-sm font-bold px-3 py-1 rounded-full mb-4">
                        MOST POPULAR
                      </div>
                    )}
                    <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                    <div className="mb-6">
                      <span className="text-5xl font-bold text-white">{plan.price}</span>
                      <span className="text-gray-400 ml-2">{plan.period}</span>
                    </div>
                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, fidx) => (
                        <li key={fidx} className="flex items-center space-x-3 text-gray-300">
                          <Check className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <a 
href={plan.link} 
target="_blank"
className={`block text-center w-full py-3 px-6 rounded-lg font-semibold transition-all ${
  plan.highlighted
    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-lg'
    : 'bg-white/20 hover:bg-white/30 text-white'
}`}
>
{plan.cta}
</a>

                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="py-20 px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-white mb-6">Ready to Create Your First Sales Page?</h2>
            <p className="text-xl text-gray-400 mb-8">Join 1,000+ creators generating high-converting sales pages with AI.</p>
            <a
              href="#generator-section"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('generator-section')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex px-10 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white text-lg font-bold rounded-xl transition-all duration-300 shadow-2xl shadow-blue-500/40 hover:shadow-blue-500/60 hover:scale-105"
            >
              Generate Your First Page
            </a>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-slate-950/80 backdrop-blur-xl py-12 px-4 mt-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-bold text-white">SellPage AI</span>
              </div>
              <p className="text-gray-400">Built for creators who want sales.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Generator</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-gray-400">
            <p>Built for creators who want sales. &copy; 2024 SellPage AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
