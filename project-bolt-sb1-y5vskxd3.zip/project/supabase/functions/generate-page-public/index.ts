const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RequestBody {
  productDescription: string;
}

interface GeneratedContent {
  id: string;
  headline: string;
  subheadline: string;
  problem: string[];
  solution: string;
  benefits: string[];
  socialProof: string;
  features: Array<{
    title: string;
    description: string;
  }>;
  guarantee: string;
  urgency: string;
  cta_primary: string;
  cta_secondary: string;
}

async function generateWithOpenAI(productDescription: string): Promise<GeneratedContent> {
  const openaiApiKey = Deno.env.get('OPENAI_API_KEY');

  if (!openaiApiKey) {
    throw new Error('OPENAI_API_KEY not configured');
  }

  const systemPrompt = `You are a world-class direct response copywriter who has created $1M+ landing pages for Shopify brands and SaaS companies. Your copy converts browsers into buyers.

Generate a premium, high-converting sales page in JSON format.

RESPONSE FORMAT (must be valid JSON):
{
  "headline": "Powerful, specific headline that triggers emotion and curiosity (8-12 words max)",
  "subheadline": "Emotional benefit-focused subheadline that clarifies and strengthens the headline (15-20 words)",
  "problem": ["Pain point 1 - specific and relatable", "Pain point 2 - specific and relatable", "Pain point 3 - specific and relatable"],
  "solution": "Paragraph (3-4 sentences) introducing how this product solves the pain. Create desire and possibility.",
  "benefits": ["Concrete benefit 1 with transformation", "Concrete benefit 2 with transformation", "Concrete benefit 3 with transformation", "Concrete benefit 4 with transformation", "Concrete benefit 5 with transformation", "Concrete benefit 6 with transformation"],
  "socialProof": "Testimonial-style social proof (2-3 sentences). Include specific results and transformation. Make it compelling and believable.",
  "features": [
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"},
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"},
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"},
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"},
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"},
    {"title": "Feature name", "description": "Why this matters to the customer and what transformation it enables (1-2 sentences)"}
  ],
  "guarantee": "Risk-reversal guarantee statement (2-3 sentences). Make them feel safe to buy. Example: 'If you don't see X result within Y days, we'll refund you, no questions asked.'",
  "urgency": "Scarcity or urgency element (1-2 sentences). Create FOMO without being pushy. Example: limited spots, price going up, limited-time bonus.",
  "cta_primary": "Primary call-to-action button text (2-4 words, action-oriented, creates urgency)",
  "cta_secondary": "Secondary call-to-action button text (2-4 words, lower commitment alternative)"
}

COPYWRITING PRINCIPLES:
1. Headline: Make it specific, benefit-driven, and emotionally resonant
2. Problem: Show deep understanding of customer pain. Make them think "Finally, someone gets it"
3. Solution: Position product as the bridge from pain to transformation
4. Benefits: Focus on outcomes, not features. "What does this do FOR me?"
5. Social Proof: Specific results, believable voice, emotional transformation
6. Features: Explain the "why" not just the "what"
7. Guarantee: Remove all risk to purchase
8. Urgency: Create FOMO with scarcity or time constraint
9. CTAs: Action-oriented, benefit-focused, create sense of urgency
10. Tone: Persuasive, confident, empathetic, premium, professional

STYLE GUIDE:
- Write like Shopify, Apple, and top dropshipping brands
- Use power words: Discover, Unlock, Transform, Finally, Proven, Tested
- Avoid generic corporate speak
- Use specific numbers and results when possible
- Write in conversational English, not stiff corporate tone
- Every sentence must move the reader closer to purchase
- No hype - credibility through specificity

Generate copy that looks like it came from a $1M landing page. Be persuasive, specific, and premium.`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: `You are creating a premium landing page for this product. Be specific, persuasive, and premium in your copy.

Product Description: ${productDescription}

Generate the complete JSON sales page copy that will convert browsers into buyers. Make it look like a $1M landing page.`,
        },
      ],
      temperature: 0.9,
      max_tokens: 2048,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error('OpenAI API error:', error);
    throw new Error(`OpenAI API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices[0].message.content;

  const parsed = JSON.parse(content);

  return {
    id: crypto.randomUUID(),
    headline: parsed.headline,
    subheadline: parsed.subheadline,
    problem: parsed.problem,
    solution: parsed.solution,
    benefits: parsed.benefits,
    socialProof: parsed.socialProof,
    features: parsed.features,
    guarantee: parsed.guarantee,
    urgency: parsed.urgency,
    cta_primary: parsed.cta_primary,
    cta_secondary: parsed.cta_secondary,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { productDescription }: RequestBody = await req.json();

    if (!productDescription || productDescription.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: 'Product description is required' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const generatedContent = await generateWithOpenAI(productDescription);

    return new Response(
      JSON.stringify({ success: true, page: generatedContent }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error generating page:', error);

    const errorMessage = error instanceof Error ? error.message : 'Internal server error';

    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
