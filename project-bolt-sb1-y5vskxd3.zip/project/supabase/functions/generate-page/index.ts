import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RequestBody {
  productDescription: string;
  userId: string;
}

function generateLandingPageContent(description: string) {
  const words = description.toLowerCase().split(' ');
  const productName = description.split(' ').slice(0, 3).join(' ');

  const headlines = [
    `Transform Your Business With ${productName}`,
    `The Ultimate Solution for ${productName}`,
    `Revolutionize Your Workflow With ${productName}`,
    `${productName}: Built for Modern Teams`,
    `Supercharge Your Productivity With ${productName}`,
  ];

  const copies = [
    `Discover how ${productName} can help you achieve your goals faster and more efficiently. Our cutting-edge technology combines innovation with simplicity to deliver exceptional results. Join thousands of satisfied customers who have already transformed their workflow.`,
    `${productName} is designed to simplify your daily tasks and boost productivity. With powerful features and an intuitive interface, you'll wonder how you ever lived without it. Start your journey to success today.`,
    `Experience the future with ${productName}. Our platform offers everything you need to stay ahead of the competition. From seamless integration to world-class support, we've got you covered every step of the way.`,
  ];

  const featureTemplates = [
    'Easy Integration',
    'Lightning Fast Performance',
    'Advanced Analytics Dashboard',
    'Real-time Collaboration',
    '24/7 Customer Support',
    'Secure Data Encryption',
    'Automated Workflows',
    'Mobile-Friendly Design',
    'Customizable Templates',
    'Team Management Tools',
  ];

  const headline = headlines[Math.floor(Math.random() * headlines.length)];
  const copy = copies[Math.floor(Math.random() * copies.length)];

  const shuffled = [...featureTemplates].sort(() => 0.5 - Math.random());
  const features = shuffled.slice(0, 6);

  const ctaOptions = ['Get Started Free', 'Start Your Free Trial', 'Try It Now', 'Sign Up Today'];
  const ctaText = ctaOptions[Math.floor(Math.random() * ctaOptions.length)];

  return {
    headline,
    copy,
    features,
    ctaText,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { productDescription, userId }: RequestBody = await req.json();

    if (!productDescription || !userId) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const generatedContent = generateLandingPageContent(productDescription);

    const { data, error } = await supabase
      .from('generated_pages')
      .insert({
        user_id: userId,
        product_description: productDescription,
        headline: generatedContent.headline,
        copy: generatedContent.copy,
        features: generatedContent.features,
        cta_text: generatedContent.ctaText,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return new Response(
      JSON.stringify({ success: true, page: data }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error generating page:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
