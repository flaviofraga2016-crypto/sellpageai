import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { GeneratedPageCard } from '../components/GeneratedPageCard';
import { supabase, GeneratedPage } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Sparkles, Loader2 } from 'lucide-react';

export function Dashboard() {
  const { user } = useAuth();
  const [productDescription, setProductDescription] = useState('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [pages, setPages] = useState<GeneratedPage[]>([]);
  const [loadingPages, setLoadingPages] = useState(true);

  useEffect(() => {
    loadPages();
  }, []);

  const loadPages = async () => {
    try {
      const { data, error } = await supabase
        .from('generated_pages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPages(data || []);
    } catch (err) {
      console.error('Error loading pages:', err);
    } finally {
      setLoadingPages(false);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setGenerating(true);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-page`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            productDescription,
            userId: user?.id
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to generate page');
      }

      const data = await response.json();

      setProductDescription('');
      await loadPages();
    } catch (err) {
      setError('Failed to generate page. Please try again.');
      console.error(err);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">
            Generate Your Landing Page
          </h1>
          <p className="text-xl text-gray-400">
            Describe your product and let AI create a high-converting landing page
          </p>
        </div>

        <div className="bg-gray-900 rounded-xl border border-gray-800 p-8 mb-12">
          <form onSubmit={handleGenerate} className="space-y-6">
            <div>
              <label
                htmlFor="description"
                className="block text-sm font-medium text-gray-300 mb-3"
              >
                Product Description
              </label>
              <textarea
                id="description"
                value={productDescription}
                onChange={(e) => setProductDescription(e.target.value)}
                rows={6}
                required
                className="w-full px-4 py-3 bg-gray-950 border border-gray-800 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Describe your product, its features, target audience, and unique value proposition..."
              />
              <p className="mt-2 text-sm text-gray-500">
                Be specific about your product's benefits and who it's for
              </p>
            </div>

            {error && (
              <div className="bg-red-900/20 border border-red-900 text-red-400 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={generating || !productDescription.trim()}
              className="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              {generating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Page</span>
                </>
              )}
            </button>
          </form>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Your Generated Pages</h2>

          {loadingPages ? (
            <div className="text-center py-12">
              <Loader2 className="w-8 h-8 text-gray-400 animate-spin mx-auto" />
            </div>
          ) : pages.length === 0 ? (
            <div className="text-center py-12 bg-gray-900 rounded-xl border border-gray-800">
              <Sparkles className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No pages generated yet. Create your first one above!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {pages.map((page) => (
                <GeneratedPageCard key={page.id} page={page} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
