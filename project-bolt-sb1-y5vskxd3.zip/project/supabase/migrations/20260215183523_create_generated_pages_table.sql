/*
  # Create Generated Pages Table

  1. New Tables
    - `generated_pages`
      - `id` (uuid, primary key) - Unique identifier for each generated page
      - `user_id` (uuid, foreign key) - References auth.users
      - `product_description` (text) - User's input description
      - `headline` (text) - AI-generated headline
      - `copy` (text) - AI-generated marketing copy
      - `features` (jsonb) - AI-generated features list
      - `cta_text` (text) - Call-to-action text
      - `created_at` (timestamptz) - Timestamp of creation
      - `updated_at` (timestamptz) - Timestamp of last update

  2. Security
    - Enable RLS on `generated_pages` table
    - Add policy for users to read their own pages
    - Add policy for users to create their own pages
    - Add policy for users to update their own pages
    - Add policy for users to delete their own pages
*/

CREATE TABLE IF NOT EXISTS generated_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  product_description text NOT NULL,
  headline text NOT NULL,
  copy text NOT NULL,
  features jsonb DEFAULT '[]'::jsonb,
  cta_text text DEFAULT 'Get Started',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE generated_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own generated pages"
  ON generated_pages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own generated pages"
  ON generated_pages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own generated pages"
  ON generated_pages FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own generated pages"
  ON generated_pages FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS generated_pages_user_id_idx ON generated_pages(user_id);
CREATE INDEX IF NOT EXISTS generated_pages_created_at_idx ON generated_pages(created_at DESC);