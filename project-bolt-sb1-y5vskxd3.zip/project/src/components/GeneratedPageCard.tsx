import { GeneratedPage } from '../lib/supabase';
import { ExternalLink, Calendar } from 'lucide-react';

type Props = {
  page: GeneratedPage;
};

export function GeneratedPageCard({ page }: Props) {
  const formattedDate = new Date(page.created_at).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-colors">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-xl font-semibold text-white line-clamp-2">
          {page.headline}
        </h3>
        <a
          href={`/page/${page.id}`}
          className="flex items-center space-x-1 text-blue-500 hover:text-blue-400 transition-colors flex-shrink-0 ml-4"
        >
          <span className="text-sm">View</span>
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>

      <p className="text-gray-400 text-sm mb-4 line-clamp-3">
        {page.copy}
      </p>

      <div className="flex items-center justify-between pt-4 border-t border-gray-800">
        <div className="flex items-center space-x-2 text-gray-500 text-sm">
          <Calendar className="w-4 h-4" />
          <span>{formattedDate}</span>
        </div>
        <span className="text-xs text-gray-600">
          {page.features.length} features
        </span>
      </div>
    </div>
  );
}
